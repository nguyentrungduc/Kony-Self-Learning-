//
//  KSErrorDomains.h
//  KonySyncV2
//
//  Created by Vishnu Satis on 03/11/17.
//  Copyright © 2017 Kony. All rights reserved.
//

#import <Foundation/Foundation.h>

//------------------------------------------------
//  Domains for Offline Object Errors
//------------------------------------------------
FOUNDATION_EXPORT NSString *const ED_OFFLINE_OBJECTS;

@interface KSErrorDomains : NSObject

@end
